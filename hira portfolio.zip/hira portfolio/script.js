// Mobile menu
const btn=document.querySelector('.menu-btn'),links=document.getElementById('links');
btn.addEventListener('click',()=>{const o=links.classList.toggle('open');btn.setAttribute('aria-expanded',o)});
links.addEventListener('click',e=>{if(e.target.tagName==='A'){links.classList.remove('open');btn.setAttribute('aria-expanded',false)}});
document.getElementById('yr').textContent=new Date().getFullYear();

// Skill bars fill when visible
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.style.width=e.target.dataset.w+'%';io.unobserve(e.target)}}),{threshold:.5});
document.querySelectorAll('.bar span').forEach(s=>io.observe(s));

// Contact form opens the visitor's email app
document.getElementById('form').addEventListener('submit',e=>{
  e.preventDefault();
  const n=name.value.trim(),m=email.value.trim(),t=msg.value.trim(),err=document.getElementById('err');
  if(!n||!t||!/^\S+@\S+\.\S+$/.test(m)){err.textContent='Enter your name, a valid email, and a message.';return}
  err.textContent='';
  location.href='mailto:samsunghira@gmail.com?subject='+encodeURIComponent('Portfolio message from '+n)+'&body='+encodeURIComponent(t+'\n\nFrom: '+n+' ('+m+')');
});

// Hero: a small neural network drawn as layers of nodes with a signal moving through it
const cv=document.getElementById('net'),ctx=cv.getContext('2d');
const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
let W,H,layers,t=0;
function build(){
  const d=devicePixelRatio||1;W=cv.clientWidth;H=cv.clientHeight;cv.width=W*d;cv.height=H*d;ctx.setTransform(d,0,0,d,0,0);
  const sizes=W<700?[3,5,5,3]:[4,6,7,6,3],x0=W<700?W*.1:W*.45,x1=W*.95;
  layers=sizes.map((n,i)=>Array.from({length:n},(_,j)=>({x:x0+(x1-x0)*i/(sizes.length-1),y:H*.15+H*.7*(j+.5)/n})));
}
function draw(){
  const s=getComputedStyle(document.documentElement),acc=s.getPropertyValue('--accent'),line=s.getPropertyValue('--line'),teal=s.getPropertyValue('--teal');
  ctx.clearRect(0,0,W,H);ctx.lineWidth=1;ctx.strokeStyle=line;
  for(let i=0;i<layers.length-1;i++)for(const a of layers[i])for(const b of layers[i+1]){ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()}
  const pos=(t/90)%layers.length;
  layers.forEach((L,i)=>L.forEach(n=>{const lit=Math.max(0,1-Math.abs(i-pos));ctx.beginPath();ctx.arc(n.x,n.y,6+lit*5,0,7);ctx.fillStyle=lit>.2?teal:acc;ctx.globalAlpha=.35+lit*.65;ctx.fill();ctx.globalAlpha=1}));
}
function loop(){t++;draw();if(!reduce)requestAnimationFrame(loop)}
build();reduce?(t=135,draw()):loop();
addEventListener('resize',()=>{build();if(reduce)draw()});
