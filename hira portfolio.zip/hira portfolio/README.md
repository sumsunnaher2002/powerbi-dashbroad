# Samsun Naher Hira - Portfolio

Personal portfolio website built with HTML, CSS, and JavaScript. No build step.

## Run locally
Open `index.html` in a browser.

## Publish with GitHub Pages
Repository Settings > Pages > Deploy from branch `main`, folder `/ (root)`.

## Edit before submitting
- Replace the project cards and GitHub links in `index.html`.
- Fill in the Education and Achievements entries.
- Adjust skill levels (`data-w` values) to match yourself.
